#pragma once
#include"Student.h"
using namespace std;

void BubbleSort(Student& stu);
