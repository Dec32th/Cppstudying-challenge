#pragma once
#include"Student.h"

void InsertionSort(Student& stu);