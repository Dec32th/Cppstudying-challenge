#pragma once
#include"Student.h"

void SelectionSort(Student& stu);
