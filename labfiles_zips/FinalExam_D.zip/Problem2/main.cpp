#include<iostream>
#include<ctime>
using namespace std;

int main()
{
	srand(time(0));
	int Cat_ = rand()%1000+1000;
	int Cat_ = rand()%1000+2000;
}