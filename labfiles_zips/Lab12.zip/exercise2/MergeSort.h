#pragma once
#include"Student.h"
#include "Student.h"

void MergeSort(Student& stu, int first, int last);
void Merge(StudentInfo values[], int leftFirst, int leftLast, int rightFirst, int rightLast);

