#pragma once
#include "Student.h"

void QuickSort(Student& stu, int first, int last);
void Split(StudentInfo values[], int first, int last, int& splitPoint);