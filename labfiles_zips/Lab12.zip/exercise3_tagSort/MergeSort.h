#pragma once
#include "Student.h"

void MergeSortPointer(Student* values[], int left, int right);

void Merge(Student* values[], int left, int mid, int right);
