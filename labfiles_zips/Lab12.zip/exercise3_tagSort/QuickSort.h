#pragma once
#include "Student.h"

void QuickSortPointer(Student* values[], int first, int last);

void Split(Student* values[], int first, int last, int& splitPoint);
