#include<iostream>
#include"TreeType.h"
using namespace std;

int main()
{
	TreeType bTree;
	bTree.InsertItem(10);
	bTree.InsertItem(5);
	bTree.InsertItem(15);
	bTree.InsertItem(2);
	bTree.InsertItem(8);

}