#include<iostream>
#include"TreeType.h"
//#include"SortedType.h"
using namespace std;

int main()
{

}