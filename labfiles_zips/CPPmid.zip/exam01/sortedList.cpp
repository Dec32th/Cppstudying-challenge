#include<iostream>
#include"sortedList.h"
using namespace std;

int main()
{
	
}